"use client"

import { useState, useEffect, useCallback } from "react"
import useSWR from "swr"

const fetcher = async (url) => {
  const token = localStorage.getItem("authToken")
  const res = await fetch(url, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  })
  if (!res.ok) throw new Error("Failed to fetch")
  return res.json()
}

export function useAuth() {
  const [isLoading, setIsLoading] = useState(true)
  const { data, error, mutate } = useSWR("/api/auth/me", fetcher, {
    revalidateOnFocus: false,
  })

  useEffect(() => {
    setIsLoading(!data && !error)
  }, [data, error])

  const login = useCallback(
    async (email, password) => {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      })
      const result = await res.json()
      if (result.token) {
        localStorage.setItem("authToken", result.token)
        mutate()
        return result.user
      }
      throw new Error(result.error)
    },
    [mutate],
  )

  const register = useCallback(
    async (email, password, name) => {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, name }),
      })
      const result = await res.json()
      if (result.token) {
        localStorage.setItem("authToken", result.token)
        mutate()
        return result.user
      }
      throw new Error(result.error)
    },
    [mutate],
  )

  const logout = useCallback(() => {
    localStorage.removeItem("authToken")
    mutate(null)
  }, [mutate])

  return {
    user: data?.user,
    isLoading,
    error,
    login,
    register,
    logout,
    mutate,
  }
}
