import { NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"

export function middleware(request) {
  const token = request.cookies.get("authToken")?.value
  const pathname = request.nextUrl.pathname

  // Public routes
  if (pathname.startsWith("/auth/")) {
    return NextResponse.next()
  }

  // Protected routes
  if (pathname.startsWith("/dashboard") || pathname.startsWith("/api/")) {
    if (!token || !verifyToken(token)) {
      if (pathname.startsWith("/api/")) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
      }
      return NextResponse.redirect(new URL("/auth/login", request.url))
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/dashboard/:path*", "/api/:path*"],
}
