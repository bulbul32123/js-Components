import { getCollection } from "@/lib/db"
import { verifyToken, getTokenFromRequest } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function POST(request) {
  try {
    const token = getTokenFromRequest(request)
    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return Response.json({ error: "Invalid token" }, { status: 401 })
    }

    const { promptId, title } = await request.json()

    const historyCollection = await getCollection("prompt_history")
    const result = await historyCollection.updateOne(
      { _id: new ObjectId(promptId), userId: new ObjectId(decoded.userId) },
      {
        $set: {
          saved: true,
          title: title || "Saved Prompt",
          savedAt: new Date(),
        },
      },
    )

    if (result.matchedCount === 0) {
      return Response.json({ error: "Prompt not found" }, { status: 404 })
    }

    return Response.json({ success: true })
  } catch (error) {
    console.error("Save prompt error:", error)
    return Response.json({ error: "Failed to save prompt" }, { status: 500 })
  }
}
