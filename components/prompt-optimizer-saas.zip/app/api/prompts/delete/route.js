import { getCollection } from "@/lib/db"
import { verifyToken, getTokenFromRequest } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function DELETE(request) {
  try {
    const token = getTokenFromRequest(request)
    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return Response.json({ error: "Invalid token" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const promptId = searchParams.get("id")

    if (!promptId) {
      return Response.json({ error: "Prompt ID required" }, { status: 400 })
    }

    const historyCollection = await getCollection("prompt_history")
    const result = await historyCollection.deleteOne({
      _id: new ObjectId(promptId),
      userId: new ObjectId(decoded.userId),
    })

    if (result.deletedCount === 0) {
      return Response.json({ error: "Prompt not found" }, { status: 404 })
    }

    return Response.json({ success: true })
  } catch (error) {
    console.error("Delete prompt error:", error)
    return Response.json({ error: "Failed to delete prompt" }, { status: 500 })
  }
}
