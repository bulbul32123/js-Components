import { getCollection } from "@/lib/db"
import { verifyToken, getTokenFromRequest } from "@/lib/auth"
import { validatePrompt } from "@/lib/validators"
import { ObjectId } from "mongodb"
import { checkRateLimit, incrementUsage } from "@/lib/rate-limiter"

// Mock optimization - replace with actual OpenAI/Gemini API calls
async function optimizePromptWithAI(prompt, model = "gpt-4") {
  // In production, call OpenAI or Gemini API here
  const improvements = [
    "Be more specific about the desired output format",
    "Include context about the target audience",
    "Add constraints or limitations to guide the response",
    "Use clear, structured language with examples",
  ]

  const optimizedPrompt = `${prompt}

[Optimized for clarity and specificity]
- Specify the exact format you want
- Include relevant context
- Define any constraints
- Provide examples if applicable`

  return {
    original: prompt,
    optimized: optimizedPrompt,
    improvements,
    model,
    timestamp: new Date(),
  }
}

export async function POST(request) {
  try {
    const token = getTokenFromRequest(request)
    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return Response.json({ error: "Invalid token" }, { status: 401 })
    }

    const { prompt, model = "gpt-4" } = await request.json()

    if (!validatePrompt(prompt)) {
      return Response.json({ error: "Invalid prompt" }, { status: 400 })
    }

    const usersCollection = await getCollection("users")
    const user = await usersCollection.findOne({ _id: new ObjectId(decoded.userId) })

    if (!user) {
      return Response.json({ error: "User not found" }, { status: 404 })
    }

    const rateLimit = await checkRateLimit(decoded.userId, user.tier)
    if (!rateLimit.allowed) {
      return Response.json({ error: rateLimit.reason }, { status: 429 })
    }

    // Optimize the prompt
    const result = await optimizePromptWithAI(prompt, model)

    await incrementUsage(decoded.userId)

    // Store in history
    const historyCollection = await getCollection("prompt_history")
    await historyCollection.insertOne({
      userId: user._id,
      ...result,
      saved: false,
      createdAt: new Date(),
    })

    return Response.json({
      ...result,
      remaining: rateLimit.remaining,
    })
  } catch (error) {
    console.error("Optimization error:", error)
    return Response.json({ error: "Optimization failed" }, { status: 500 })
  }
}
