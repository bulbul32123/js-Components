import { getCollection } from "@/lib/db"
import { verifyToken, getTokenFromRequest } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function GET(request) {
  try {
    const token = getTokenFromRequest(request)
    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return Response.json({ error: "Invalid token" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const page = Number.parseInt(searchParams.get("page")) || 1
    const limit = Number.parseInt(searchParams.get("limit")) || 10
    const skip = (page - 1) * limit

    const historyCollection = await getCollection("prompt_history")
    const total = await historyCollection.countDocuments({ userId: new ObjectId(decoded.userId) })

    const history = await historyCollection
      .find({ userId: new ObjectId(decoded.userId) })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .toArray()

    return Response.json({
      history: history.map((item) => ({
        id: item._id.toString(),
        original: item.original,
        optimized: item.optimized,
        improvements: item.improvements,
        model: item.model,
        saved: item.saved,
        createdAt: item.createdAt,
      })),
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("History fetch error:", error)
    return Response.json({ error: "Failed to fetch history" }, { status: 500 })
  }
}
