import { getCollection } from "@/lib/db"
import { validatePrompt } from "@/lib/validators"
import { checkRateLimit, incrementUsage } from "@/lib/rate-limiter"

// Public API endpoint for programmatic access
export async function POST(request) {
  try {
    const apiKey = request.headers.get("x-api-key")
    if (!apiKey) {
      return Response.json({ error: "API key required" }, { status: 401 })
    }

    const usersCollection = await getCollection("users")
    const user = await usersCollection.findOne({ apiKey })

    if (!user) {
      return Response.json({ error: "Invalid API key" }, { status: 401 })
    }

    const { prompt, model = "gpt-4" } = await request.json()

    if (!validatePrompt(prompt)) {
      return Response.json({ error: "Invalid prompt" }, { status: 400 })
    }

    // Check rate limits
    const rateLimit = await checkRateLimit(user._id.toString(), user.tier)
    if (!rateLimit.allowed) {
      return Response.json({ error: rateLimit.reason }, { status: 429 })
    }

    // Optimize the prompt
    const improvements = [
      "Enhanced clarity and specificity",
      "Added structured formatting",
      "Improved context and examples",
      "Optimized for better AI comprehension",
    ]

    const optimized = `${prompt}\n\n[API Optimized]\n- ${improvements.join("\n- ")}`

    // Increment usage
    await incrementUsage(user._id.toString())

    // Store in history
    const historyCollection = await getCollection("prompt_history")
    await historyCollection.insertOne({
      userId: user._id,
      original: prompt,
      optimized,
      improvements,
      model,
      saved: false,
      createdAt: new Date(),
      source: "api",
    })

    return Response.json({
      original: prompt,
      optimized,
      improvements,
      model,
      remaining: rateLimit.remaining,
    })
  } catch (error) {
    console.error("API optimization error:", error)
    return Response.json({ error: "Optimization failed" }, { status: 500 })
  }
}
