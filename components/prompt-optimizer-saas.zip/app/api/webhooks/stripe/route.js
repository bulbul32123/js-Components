import stripe from "@/lib/stripe"
import { getCollection } from "@/lib/db"
import { ObjectId } from "mongodb"

export async function POST(request) {
  const body = await request.text()
  const sig = request.headers.get("stripe-signature")

  let event

  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET)
  } catch (err) {
    console.error("Webhook signature verification failed:", err)
    return Response.json({ error: "Invalid signature" }, { status: 400 })
  }

  try {
    const usersCollection = await getCollection("users")

    switch (event.type) {
      case "customer.subscription.updated":
      case "customer.subscription.created": {
        const subscription = event.data.object
        const customer = await stripe.customers.retrieve(subscription.customer)

        const userId = customer.metadata?.userId
        if (userId) {
          const tier = subscription.items.data[0]?.price?.metadata?.tier || "free"
          await usersCollection.updateOne(
            { _id: new ObjectId(userId) },
            {
              $set: {
                tier,
                stripeSubscriptionId: subscription.id,
                stripeSubscriptionStatus: subscription.status,
              },
            },
          )
        }
        break
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object
        const customer = await stripe.customers.retrieve(subscription.customer)

        const userId = customer.metadata?.userId
        if (userId) {
          await usersCollection.updateOne(
            { _id: new ObjectId(userId) },
            {
              $set: {
                tier: "free",
                stripeSubscriptionStatus: "canceled",
              },
            },
          )
        }
        break
      }

      case "invoice.payment_succeeded": {
        const invoice = event.data.object
        console.log("Payment succeeded:", invoice.id)
        break
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object
        console.error("Payment failed:", invoice.id)
        break
      }
    }

    return Response.json({ received: true })
  } catch (error) {
    console.error("Webhook processing error:", error)
    return Response.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
