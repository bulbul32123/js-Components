import { getCollection } from "@/lib/db"
import { verifyToken, getTokenFromRequest } from "@/lib/auth"
import { ObjectId } from "mongodb"
import crypto from "crypto"

export async function POST(request) {
  try {
    const token = getTokenFromRequest(request)
    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return Response.json({ error: "Invalid token" }, { status: 401 })
    }

    const apiKey = crypto.randomBytes(32).toString("hex")

    const usersCollection = await getCollection("users")
    const result = await usersCollection.updateOne(
      { _id: new ObjectId(decoded.userId) },
      {
        $set: {
          apiKey,
          apiKeyCreatedAt: new Date(),
        },
      },
    )

    if (result.matchedCount === 0) {
      return Response.json({ error: "User not found" }, { status: 404 })
    }

    return Response.json({ apiKey })
  } catch (error) {
    console.error("API key generation error:", error)
    return Response.json({ error: "Failed to generate API key" }, { status: 500 })
  }
}

export async function DELETE(request) {
  try {
    const token = getTokenFromRequest(request)
    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return Response.json({ error: "Invalid token" }, { status: 401 })
    }

    const usersCollection = await getCollection("users")
    const result = await usersCollection.updateOne(
      { _id: new ObjectId(decoded.userId) },
      {
        $unset: {
          apiKey: "",
          apiKeyCreatedAt: "",
        },
      },
    )

    if (result.matchedCount === 0) {
      return Response.json({ error: "User not found" }, { status: 404 })
    }

    return Response.json({ success: true })
  } catch (error) {
    console.error("API key deletion error:", error)
    return Response.json({ error: "Failed to delete API key" }, { status: 500 })
  }
}
