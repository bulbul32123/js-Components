import { getCollection } from "@/lib/db"
import { verifyToken, getTokenFromRequest } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function GET(request) {
  try {
    const token = getTokenFromRequest(request)
    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return Response.json({ error: "Invalid token" }, { status: 401 })
    }

    const userId = new ObjectId(decoded.userId)
    const usersCollection = await getCollection("users")
    const historyCollection = await getCollection("prompt_history")

    const user = await usersCollection.findOne({ _id: userId })
    if (!user) {
      return Response.json({ error: "User not found" }, { status: 404 })
    }

    // Get total prompts optimized
    const totalPrompts = await historyCollection.countDocuments({ userId })

    // Get saved prompts
    const savedPrompts = await historyCollection.countDocuments({ userId, saved: true })

    // Get this month's usage
    const now = new Date()
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)
    const thisMonthPrompts = await historyCollection.countDocuments({
      userId,
      createdAt: { $gte: monthStart },
    })

    // Get daily usage for last 7 days
    const dailyUsage = []
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)
      date.setHours(0, 0, 0, 0)

      const nextDate = new Date(date)
      nextDate.setDate(nextDate.getDate() + 1)

      const count = await historyCollection.countDocuments({
        userId,
        createdAt: { $gte: date, $lt: nextDate },
      })

      dailyUsage.push({
        date: date.toISOString().split("T")[0],
        count,
      })
    }

    return Response.json({
      stats: {
        totalPrompts,
        savedPrompts,
        thisMonthPrompts,
        apiCallsToday: user.apiUsage?.apiCallsToday || 0,
        tier: user.tier,
      },
      dailyUsage,
    })
  } catch (error) {
    console.error("Analytics error:", error)
    return Response.json({ error: "Failed to fetch analytics" }, { status: 500 })
  }
}
