import { getCollection } from "@/lib/db"
import { verifyToken, getTokenFromRequest } from "@/lib/auth"
import { ObjectId } from "mongodb"

export async function GET(request) {
  try {
    const token = getTokenFromRequest(request)
    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return Response.json({ error: "Invalid token" }, { status: 401 })
    }

    const usersCollection = await getCollection("users")
    const user = await usersCollection.findOne({ _id: new ObjectId(decoded.userId) })

    if (!user) {
      return Response.json({ error: "User not found" }, { status: 404 })
    }

    return Response.json({
      user: {
        id: user._id.toString(),
        email: user.email,
        name: user.name,
        tier: user.tier,
        apiUsage: user.apiUsage,
      },
    })
  } catch (error) {
    console.error("Auth check error:", error)
    return Response.json({ error: "Auth check failed" }, { status: 500 })
  }
}
