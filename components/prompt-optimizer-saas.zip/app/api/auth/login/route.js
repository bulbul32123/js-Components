import { getCollection } from "@/lib/db"
import { comparePassword, generateToken } from "@/lib/auth"
import { validateEmail } from "@/lib/validators"

export async function POST(request) {
  try {
    const { email, password } = await request.json()

    if (!validateEmail(email)) {
      return Response.json({ error: "Invalid email" }, { status: 400 })
    }

    const usersCollection = await getCollection("users")
    const user = await usersCollection.findOne({ email })

    if (!user) {
      return Response.json({ error: "Invalid credentials" }, { status: 401 })
    }

    const passwordMatch = await comparePassword(password, user.password)
    if (!passwordMatch) {
      return Response.json({ error: "Invalid credentials" }, { status: 401 })
    }

    const token = generateToken(user._id.toString())

    return Response.json({
      token,
      user: {
        id: user._id.toString(),
        email: user.email,
        name: user.name,
        tier: user.tier,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    return Response.json({ error: "Login failed" }, { status: 500 })
  }
}
