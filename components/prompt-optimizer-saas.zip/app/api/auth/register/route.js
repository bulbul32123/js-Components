import { getCollection } from "@/lib/db"
import { hashPassword, generateToken } from "@/lib/auth"
import { validateEmail, validatePassword } from "@/lib/validators"

export async function POST(request) {
  try {
    const { email, password, name } = await request.json()

    if (!validateEmail(email)) {
      return Response.json({ error: "Invalid email" }, { status: 400 })
    }

    if (!validatePassword(password)) {
      return Response.json({ error: "Password must be at least 8 characters" }, { status: 400 })
    }

    const usersCollection = await getCollection("users")
    const existingUser = await usersCollection.findOne({ email })

    if (existingUser) {
      return Response.json({ error: "Email already registered" }, { status: 400 })
    }

    const hashedPassword = await hashPassword(password)
    const user = {
      email,
      password: hashedPassword,
      name: name || email.split("@")[0],
      tier: "free",
      createdAt: new Date(),
      updatedAt: new Date(),
      apiUsage: {
        promptsThisMonth: 0,
        apiCallsToday: 0,
        lastResetDate: new Date(),
      },
    }

    const result = await usersCollection.insertOne(user)
    const token = generateToken(result.insertedId.toString())

    return Response.json({
      token,
      user: {
        id: result.insertedId.toString(),
        email: user.email,
        name: user.name,
        tier: user.tier,
      },
    })
  } catch (error) {
    console.error("Registration error:", error)
    return Response.json({ error: "Registration failed" }, { status: 500 })
  }
}
