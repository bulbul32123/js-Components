"use client"

import { PricingCards } from "@/components/pricing-cards"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CreditCard } from "lucide-react"
import { useAuth } from "@/hooks/useAuth"
import { useState } from "react"
import { useSearchParams } from "next/navigation"

export default function BillingPage() {
  const { user } = useAuth()
  const searchParams = useSearchParams()
  const [isLoadingPortal, setIsLoadingPortal] = useState(false)

  const handleManageBilling = async () => {
    setIsLoadingPortal(true)
    try {
      const token = localStorage.getItem("authToken")
      const res = await fetch("/api/billing/portal", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const { url } = await res.json()
      window.location.href = url
    } catch (err) {
      console.error("Portal error:", err)
    } finally {
      setIsLoadingPortal(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <CreditCard className="w-8 h-8 text-primary" />
          Billing & Plans
        </h1>
        <p className="text-muted-foreground mt-2">Manage your subscription and billing</p>
      </div>

      {/* Success/Cancel Messages */}
      {searchParams.get("success") && (
        <Card className="bg-green-500/10 border-green-500/20">
          <CardContent className="pt-6">
            <p className="text-green-700 dark:text-green-400">Upgrade successful! Your plan is now active.</p>
          </CardContent>
        </Card>
      )}

      {searchParams.get("canceled") && (
        <Card className="bg-yellow-500/10 border-yellow-500/20">
          <CardContent className="pt-6">
            <p className="text-yellow-700 dark:text-yellow-400">Checkout was canceled. Your plan remains unchanged.</p>
          </CardContent>
        </Card>
      )}

      {/* Current Plan */}
      {user && (
        <Card>
          <CardHeader>
            <CardTitle>Current Plan</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-semibold text-lg">{user.tier.charAt(0).toUpperCase() + user.tier.slice(1)}</p>
                <p className="text-sm text-muted-foreground">Active subscription</p>
              </div>
              {user.tier !== "free" && (
                <Button onClick={handleManageBilling} disabled={isLoadingPortal} variant="outline">
                  {isLoadingPortal ? "Loading..." : "Manage Subscription"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Pricing Plans */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Choose Your Plan</h2>
        <PricingCards />
      </div>
    </div>
  )
}
