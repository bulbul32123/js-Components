"use client"

import { HistoryList } from "@/components/history-list"
import { History } from "lucide-react"

export default function HistoryPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <History className="w-8 h-8 text-primary" />
          Prompt History
        </h1>
        <p className="text-muted-foreground mt-2">View and manage all your optimized prompts</p>
      </div>

      <HistoryList />
    </div>
  )
}
