"use client"

import { AnalyticsCards } from "@/components/analytics-cards"
import { UsageChart } from "@/components/usage-chart"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart3 } from "lucide-react"

export default function AnalyticsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <BarChart3 className="w-8 h-8 text-primary" />
          Analytics
        </h1>
        <p className="text-muted-foreground mt-2">Track your optimization usage and improvements</p>
      </div>

      {/* Stats Cards */}
      <AnalyticsCards />

      {/* Usage Chart */}
      <UsageChart />

      {/* Insights */}
      <Card>
        <CardHeader>
          <CardTitle>Key Insights</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-3">
            <div className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-sm">Consistent Usage</p>
              <p className="text-xs text-muted-foreground">You're using the optimizer regularly. Keep it up!</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-sm">Save Your Best Prompts</p>
              <p className="text-xs text-muted-foreground">Save your most effective prompts for quick access later.</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-sm">Upgrade for More</p>
              <p className="text-xs text-muted-foreground">Consider upgrading to Pro for unlimited optimizations.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
