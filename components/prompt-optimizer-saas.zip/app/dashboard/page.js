"use client"

import { PromptOptimizer } from "@/components/prompt-optimizer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Zap className="w-8 h-8 text-primary" />
          Prompt Optimizer
        </h1>
        <p className="text-muted-foreground mt-2">Transform your AI prompts into powerful, effective instructions</p>
      </div>

      {/* Quick Tips */}
      <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
        <CardHeader>
          <CardTitle className="text-lg">Tips for Better Prompts</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <li className="flex gap-2">
              <span className="text-primary font-bold">•</span>
              <span>Be specific about what you want</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary font-bold">•</span>
              <span>Provide context and background</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary font-bold">•</span>
              <span>Include examples when possible</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary font-bold">•</span>
              <span>Define constraints and limitations</span>
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Main Optimizer */}
      <PromptOptimizer />
    </div>
  )
}
