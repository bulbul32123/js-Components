"use client"

import { ApiDocumentation } from "@/components/api-documentation"
import { Code } from "lucide-react"

export default function ApiPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Code className="w-8 h-8 text-primary" />
          API Reference
        </h1>
        <p className="text-muted-foreground mt-2">Integrate Prompt Optimizer into your applications</p>
      </div>

      <ApiDocumentation />
    </div>
  )
}
