# Prompt Optimizer SaaS

A modern, full-featured SaaS application that helps users improve their AI prompts with intelligent optimization. Built with Next.js, Tailwind CSS, MongoDB, and Stripe.

## Features

### Core Features
- **Prompt Optimization**: AI-powered prompt enhancement with improvement suggestions
- **Prompt History**: Track and manage all optimized prompts with pagination
- **User Authentication**: Email/password authentication with JWT tokens
- **Light/Dark Mode**: Beautiful theme toggle with persistent preferences
- **Responsive Design**: Mobile-first, fully responsive UI

### Advanced Features
- **Analytics Dashboard**: Track usage, API calls, and optimization metrics
- **Subscription Tiers**: Free, Pro, and Enterprise plans with Stripe integration
- **Rate Limiting**: Tier-based API rate limits (5/day free, 100/day pro, unlimited enterprise)
- **API Key Management**: Generate and manage API keys for programmatic access
- **Public API**: RESTful API endpoint for integrating into external applications
- **Billing Portal**: Manage subscriptions and billing through Stripe

## Tech Stack

- **Frontend**: Next.js 15+ (App Router), React, Tailwind CSS v4
- **Backend**: Next.js API Routes
- **Database**: MongoDB
- **Authentication**: JWT + bcrypt
- **Payments**: Stripe
- **UI Components**: shadcn/ui
- **Charts**: Recharts
- **Icons**: Lucide React

## Project Structure

\`\`\`
app/
├── api/
│   ├── auth/              # Authentication endpoints
│   ├── prompts/           # Prompt optimization endpoints
│   ├── analytics/         # Analytics endpoints
│   ├── users/             # User management endpoints
│   ├── billing/           # Stripe billing endpoints
│   ├── webhooks/          # Stripe webhooks
│   └── v1/                # Public API endpoints
├── auth/                  # Auth pages (login, register)
├── dashboard/             # Protected dashboard pages
│   ├── page.js           # Main optimizer
│   ├── history/          # Prompt history
│   ├── analytics/        # Analytics dashboard
│   ├── settings/         # User settings
│   ├── billing/          # Billing & plans
│   └── api/              # API documentation
├── layout.js             # Root layout
├── page.js               # Landing page
└── globals.css           # Global styles

components/
├── auth-form.js          # Login/register form
├── prompt-optimizer.js   # Main optimizer component
├── history-list.js       # Prompt history list
├── analytics-cards.js    # Analytics stat cards
├── usage-chart.js        # Usage chart
├── profile-settings.js   # Profile management
├── api-key-settings.js   # API key management
├── pricing-cards.js      # Pricing plans
├── api-documentation.js  # API docs
├── sidebar.js            # Navigation sidebar
└── theme-toggle.js       # Dark mode toggle

lib/
├── db.js                 # MongoDB connection
├── auth.js               # JWT & password utilities
├── constants.js          # Subscription tiers & limits
├── validators.js         # Input validation
├── rate-limiter.js       # Rate limiting logic
├── ai-providers.js       # AI provider integrations
└── stripe.js             # Stripe client

hooks/
├── useAuth.js            # Authentication hook
└── use-mobile.tsx        # Mobile detection hook

middleware.js             # Route protection middleware
\`\`\`

## Environment Variables

Create a `.env.local` file with the following variables:

\`\`\`env
# Database
MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/
MONGODB_DB=prompt-optimizer

# Authentication
JWT_SECRET=your-secret-key-change-in-production

# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRO_MONTHLY_PRICE_ID=price_...
STRIPE_PRO_ANNUAL_PRICE_ID=price_...
STRIPE_ENTERPRISE_PRICE_ID=price_...

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000

# AI APIs (Optional - for real integrations)
OPENAI_API_KEY=sk_...
GEMINI_API_KEY=...
\`\`\`

## Getting Started

### Prerequisites
- Node.js 18+
- MongoDB Atlas account
- Stripe account

### Installation

1. Clone the repository
\`\`\`bash
git clone <repository-url>
cd prompt-optimizer
\`\`\`

2. Install dependencies
\`\`\`bash
npm install
\`\`\`

3. Set up environment variables
\`\`\`bash
cp .env.example .env.local
# Edit .env.local with your credentials
\`\`\`

4. Run the development server
\`\`\`bash
npm run dev
\`\`\`

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## API Documentation

### Authentication Endpoints

#### Register
\`\`\`bash
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123",
  "name": "John Doe"
}
\`\`\`

#### Login
\`\`\`bash
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}
\`\`\`

#### Get Current User
\`\`\`bash
GET /api/auth/me
Authorization: Bearer <token>
\`\`\`

### Prompt Optimization

#### Optimize Prompt
\`\`\`bash
POST /api/prompts/optimize
Authorization: Bearer <token>
Content-Type: application/json

{
  "prompt": "Your prompt here",
  "model": "gpt-4"
}
\`\`\`

#### Get History
\`\`\`bash
GET /api/prompts/history?page=1&limit=10
Authorization: Bearer <token>
\`\`\`

#### Save Prompt
\`\`\`bash
POST /api/prompts/save
Authorization: Bearer <token>
Content-Type: application/json

{
  "promptId": "...",
  "title": "My Saved Prompt"
}
\`\`\`

#### Delete Prompt
\`\`\`bash
DELETE /api/prompts/delete?id=<promptId>
Authorization: Bearer <token>
\`\`\`

### Public API

#### Optimize (API Key)
\`\`\`bash
POST /api/v1/optimize
x-api-key: your-api-key
Content-Type: application/json

{
  "prompt": "Your prompt here",
  "model": "gpt-4"
}
\`\`\`

## Subscription Tiers

### Free
- 10 prompts/month
- 5 API calls/day
- Basic optimization
- Prompt history

### Pro ($29/month)
- 500 prompts/month
- 100 API calls/day
- Advanced optimization
- Full analytics
- Priority support

### Enterprise (Custom)
- Unlimited prompts
- Unlimited API calls
- Custom models
- Dedicated support
- API access

## Rate Limiting

Rate limits are enforced per tier:

| Tier | Daily Limit | Monthly Limit |
|------|------------|---------------|
| Free | 5 | 10 |
| Pro | 100 | 500 |
| Enterprise | Unlimited | Unlimited |

## Database Schema

### Users Collection
\`\`\`javascript
{
  _id: ObjectId,
  email: String,
  password: String (hashed),
  name: String,
  tier: String, // 'free', 'pro', 'enterprise'
  apiKey: String,
  stripeCustomerId: String,
  stripeSubscriptionId: String,
  stripeSubscriptionStatus: String,
  apiUsage: {
    promptsThisMonth: Number,
    apiCallsToday: Number,
    lastResetDate: Date
  },
  createdAt: Date,
  updatedAt: Date
}
\`\`\`

### Prompt History Collection
\`\`\`javascript
{
  _id: ObjectId,
  userId: ObjectId,
  original: String,
  optimized: String,
  improvements: [String],
  model: String,
  saved: Boolean,
  title: String,
  source: String, // 'web' or 'api'
  createdAt: Date,
  savedAt: Date
}
\`\`\`

## Deployment

### Deploy to Vercel

1. Push your code to GitHub
2. Connect your repository to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

\`\`\`bash
vercel deploy
\`\`\`

### MongoDB Atlas Setup

1. Create a cluster on MongoDB Atlas
2. Create a database user
3. Get connection string
4. Add to `MONGODB_URI` environment variable

### Stripe Setup

1. Create a Stripe account
2. Create products and prices
3. Add price IDs to environment variables
4. Set up webhook endpoint: `https://yourdomain.com/api/webhooks/stripe`

## Development

### Running Tests
\`\`\`bash
npm run test
\`\`\`

### Building for Production
\`\`\`bash
npm run build
npm start
\`\`\`

### Code Quality
\`\`\`bash
npm run lint
\`\`\`

## Future Enhancements

- [ ] Real OpenAI/Gemini API integration
- [ ] Batch prompt optimization
- [ ] Prompt templates library
- [ ] Team collaboration features
- [ ] Advanced analytics and reporting
- [ ] Custom AI model training
- [ ] Webhook integrations
- [ ] Mobile app

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@promptoptimizer.com or open an issue on GitHub.

## Acknowledgments

- Built with [Next.js](https://nextjs.org/)
- UI components from [shadcn/ui](https://ui.shadcn.com/)
- Icons from [Lucide React](https://lucide.dev/)
- Charts from [Recharts](https://recharts.org/)
- Payments powered by [Stripe](https://stripe.com/)
\`\`\`

```js file="" isHidden
