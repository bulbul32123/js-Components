# Prompt Optimizer SaaS - Setup Guide

This guide will walk you through setting up the Prompt Optimizer SaaS application from scratch.

## Prerequisites

- Node.js 18+ installed
- npm or yarn package manager
- MongoDB Atlas account (free tier available)
- Stripe account (free tier available)
- Git

## Step 1: Clone and Install

\`\`\`bash
# Clone the repository
git clone <your-repo-url>
cd prompt-optimizer

# Install dependencies
npm install
\`\`\`

## Step 2: MongoDB Setup

### Create MongoDB Atlas Cluster

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)
2. Sign up or log in
3. Create a new project
4. Create a new cluster (free tier is fine)
5. Wait for cluster to be created (5-10 minutes)

### Get Connection String

1. Click "Connect" on your cluster
2. Choose "Drivers"
3. Select Node.js and version 5.5 or later
4. Copy the connection string
5. Replace `<password>` with your database user password
6. Replace `myFirstDatabase` with `prompt-optimizer`

Example:
\`\`\`
mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/prompt-optimizer?retryWrites=true&w=majority
\`\`\`

## Step 3: Stripe Setup

### Create Stripe Account

1. Go to [Stripe](https://stripe.com)
2. Sign up for a free account
3. Complete the onboarding

### Get API Keys

1. Go to Developers → API Keys
2. Copy your **Secret Key** (starts with `sk_test_`)
3. Copy your **Publishable Key** (starts with `pk_test_`)

### Create Products and Prices

1. Go to Products
2. Create a new product called "Pro Monthly"
   - Price: $29/month
   - Billing period: Monthly
   - Copy the Price ID (starts with `price_`)

3. Create another product called "Pro Annual"
   - Price: $290/year
   - Billing period: Annual
   - Copy the Price ID

4. Create "Enterprise" product
   - Price: Custom (set to $999/month for testing)
   - Copy the Price ID

### Set Up Webhook

1. Go to Developers → Webhooks
2. Click "Add endpoint"
3. Endpoint URL: `https://yourdomain.com/api/webhooks/stripe`
   - For local development: Use [ngrok](https://ngrok.com) to expose localhost
   - Command: `ngrok http 3000`
   - Use the ngrok URL: `https://xxxxx.ngrok.io/api/webhooks/stripe`
4. Select events:
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
5. Copy the Signing Secret (starts with `whsec_`)

## Step 4: Environment Variables

1. Create `.env.local` file in the root directory
2. Copy contents from `.env.example`
3. Fill in your values:

\`\`\`env
# Database
MONGODB_URI=mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/prompt-optimizer?retryWrites=true&w=majority
MONGODB_DB=prompt-optimizer

# Authentication
JWT_SECRET=your-super-secret-key-min-32-characters-long

# Stripe
STRIPE_SECRET_KEY=sk_test_your_key_here
STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here
STRIPE_PRO_MONTHLY_PRICE_ID=price_xxxxx
STRIPE_PRO_ANNUAL_PRICE_ID=price_xxxxx
STRIPE_ENTERPRISE_PRICE_ID=price_xxxxx

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
\`\`\`

## Step 5: Run Development Server

\`\`\`bash
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Step 6: Test the Application

### Create Test Account

1. Click "Get Started" on the landing page
2. Sign up with test email: `test@example.com`
3. Password: `password123`

### Test Prompt Optimization

1. Go to Dashboard
2. Enter a test prompt
3. Click "Optimize"
4. View the optimized version

### Test Stripe Integration

1. Go to Billing & Plans
2. Click "Upgrade to Pro"
3. Use Stripe test card: `4242 4242 4242 4242`
4. Expiry: Any future date (e.g., 12/25)
5. CVC: Any 3 digits (e.g., 123)
6. Complete the checkout

### Test Webhook (Local Development)

1. Start ngrok: `ngrok http 3000`
2. Update Stripe webhook URL with ngrok URL
3. In Stripe dashboard, go to Webhooks
4. Click your endpoint and "Send test event"
5. Check your app logs for webhook processing

## Step 7: Database Initialization

The app will automatically create collections on first use. To manually initialize:

\`\`\`javascript
// In MongoDB Atlas, go to Collections and create:
// - users
// - prompt_history
\`\`\`

## Step 8: Deploy to Vercel

### Prepare for Deployment

1. Push code to GitHub
2. Go to [Vercel](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Add environment variables:
   - Copy all values from `.env.local`
   - Paste into Vercel environment variables
6. Deploy

### Update Stripe Webhook

1. After deployment, update Stripe webhook URL to your production domain
2. Example: `https://yourdomain.com/api/webhooks/stripe`

## Troubleshooting

### MongoDB Connection Error

- Check connection string in `.env.local`
- Verify IP whitelist in MongoDB Atlas (should be 0.0.0.0/0 for development)
- Ensure database user password is correct

### Stripe Webhook Not Working

- Verify webhook URL is accessible
- Check webhook signing secret matches `STRIPE_WEBHOOK_SECRET`
- Use ngrok for local testing
- Check Stripe dashboard for webhook logs

### Authentication Issues

- Clear browser cookies and localStorage
- Verify JWT_SECRET is set
- Check MongoDB users collection exists

### Rate Limiting Not Working

- Verify user tier is set correctly in MongoDB
- Check `apiUsage` object exists in user document
- Ensure date comparison logic is correct

## Next Steps

1. **Integrate Real AI APIs**
   - Replace mock optimization with OpenAI or Gemini API calls
   - Add API key validation

2. **Add Email Notifications**
   - Send welcome emails on signup
   - Send billing notifications

3. **Implement Advanced Features**
   - Batch prompt optimization
   - Prompt templates
   - Team collaboration
   - Custom models

4. **Set Up Monitoring**
   - Add error tracking (Sentry)
   - Set up analytics (Vercel Analytics)
   - Monitor API usage

5. **Security Hardening**
   - Add rate limiting middleware
   - Implement CSRF protection
   - Add input sanitization
   - Set up security headers

## Support

For issues or questions:
1. Check the README.md
2. Review error logs in browser console
3. Check Vercel/MongoDB/Stripe dashboards
4. Open an issue on GitHub

## Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [MongoDB Atlas Documentation](https://docs.atlas.mongodb.com/)
- [Stripe Documentation](https://stripe.com/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
