"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/hooks/useAuth"
import useSWR from "swr"

const fetcher = async (url) => {
  const token = localStorage.getItem("authToken")
  const res = await fetch(url, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  })
  if (!res.ok) throw new Error("Failed to fetch")
  return res.json()
}

export function ProfileSettings() {
  const { user, mutate } = useAuth()
  const { data, error } = useSWR("/api/users/profile", fetcher)
  const [name, setName] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [message, setMessage] = useState("")

  const handleSave = async () => {
    setIsSaving(true)
    setMessage("")

    try {
      const token = localStorage.getItem("authToken")
      const res = await fetch("/api/users/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ name }),
      })

      if (res.ok) {
        setMessage("Profile updated successfully")
        mutate()
        setTimeout(() => setMessage(""), 3000)
      }
    } catch (err) {
      setMessage("Failed to update profile")
    } finally {
      setIsSaving(false)
    }
  }

  if (error) {
    return <div className="text-destructive">Failed to load profile</div>
  }

  if (!data) {
    return <div className="text-muted-foreground">Loading profile...</div>
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Profile Information</CardTitle>
        <CardDescription>Update your account details</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium">Email</label>
          <Input type="email" value={data.user.email} disabled className="mt-1" />
          <p className="text-xs text-muted-foreground mt-1">Email cannot be changed</p>
        </div>

        <div>
          <label className="text-sm font-medium">Full Name</label>
          <Input
            value={name || data.user.name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your name"
            className="mt-1"
          />
        </div>

        <div>
          <label className="text-sm font-medium">Subscription Tier</label>
          <div className="mt-1 px-3 py-2 bg-muted rounded-md text-sm font-semibold">{data.user.tier.toUpperCase()}</div>
        </div>

        <div>
          <label className="text-sm font-medium">Member Since</label>
          <div className="mt-1 px-3 py-2 bg-muted rounded-md text-sm">
            {new Date(data.user.createdAt).toLocaleDateString()}
          </div>
        </div>

        {message && <p className="text-sm text-green-600">{message}</p>}

        <Button onClick={handleSave} disabled={isSaving} className="w-full">
          {isSaving ? "Saving..." : "Save Changes"}
        </Button>
      </CardContent>
    </Card>
  )
}
