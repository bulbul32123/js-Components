"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Copy, Zap, Loader2 } from "lucide-react"

export function PromptOptimizer() {
  const [prompt, setPrompt] = useState("")
  const [optimized, setOptimized] = useState(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [copied, setCopied] = useState(false)

  const handleOptimize = async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt")
      return
    }

    setIsLoading(true)
    setError("")

    try {
      const token = localStorage.getItem("authToken")
      const res = await fetch("/api/prompts/optimize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ prompt }),
      })

      const data = await res.json()
      if (!res.ok) {
        setError(data.error || "Failed to optimize prompt")
        return
      }

      setOptimized(data)
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(optimized.optimized)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Input Section */}
      <Card className="flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Original Prompt
          </CardTitle>
          <CardDescription>Enter your AI prompt to optimize</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col gap-4">
          <Textarea
            placeholder="Enter your prompt here... (max 5000 characters)"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="flex-1 min-h-64 resize-none"
            maxLength={5000}
          />
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">{prompt.length}/5000</span>
            <Button onClick={handleOptimize} disabled={isLoading || !prompt.trim()} className="gap-2">
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Optimizing...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Optimize
                </>
              )}
            </Button>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      {/* Output Section */}
      <Card className="flex flex-col">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Optimized Prompt</span>
            {optimized && (
              <Button variant="ghost" size="sm" onClick={handleCopy} className="gap-2">
                <Copy className="w-4 h-4" />
                {copied ? "Copied!" : "Copy"}
              </Button>
            )}
          </CardTitle>
          <CardDescription>AI-enhanced version of your prompt</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col gap-4">
          {optimized ? (
            <>
              <div className="bg-muted p-4 rounded-lg min-h-64 max-h-64 overflow-y-auto">
                <p className="text-sm whitespace-pre-wrap">{optimized.optimized}</p>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Improvements Made:</h4>
                <ul className="space-y-1">
                  {optimized.improvements.map((improvement, idx) => (
                    <li key={idx} className="text-sm text-muted-foreground flex gap-2">
                      <span className="text-primary">•</span>
                      {improvement}
                    </li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center min-h-64 text-muted-foreground">
              <p>Optimize a prompt to see the enhanced version here</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
