"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Copy, Trash2, Save, Loader2 } from "lucide-react"
import useSWR from "swr"

const fetcher = async (url) => {
  const token = localStorage.getItem("authToken")
  const res = await fetch(url, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  })
  if (!res.ok) throw new Error("Failed to fetch")
  return res.json()
}

export function HistoryList() {
  const [page, setPage] = useState(1)
  const [copied, setCopied] = useState(null)
  const [deleting, setDeleting] = useState(null)
  const { data, error, mutate } = useSWR(`/api/prompts/history?page=${page}&limit=10`, fetcher)

  const handleCopy = (text, id) => {
    navigator.clipboard.writeText(text)
    setCopied(id)
    setTimeout(() => setCopied(null), 2000)
  }

  const handleDelete = async (id) => {
    setDeleting(id)
    try {
      const token = localStorage.getItem("authToken")
      const res = await fetch(`/api/prompts/delete?id=${id}`, {
        method: "DELETE",
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      })

      if (res.ok) {
        mutate()
      }
    } catch (err) {
      console.error("Delete error:", err)
    } finally {
      setDeleting(null)
    }
  }

  const handleSave = async (id) => {
    try {
      const token = localStorage.getItem("authToken")
      const res = await fetch("/api/prompts/save", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ promptId: id }),
      })

      if (res.ok) {
        mutate()
      }
    } catch (err) {
      console.error("Save error:", err)
    }
  }

  if (error) {
    return <div className="text-center text-destructive">Failed to load history</div>
  }

  if (!data) {
    return <div className="text-center text-muted-foreground">Loading history...</div>
  }

  return (
    <div className="space-y-4">
      {data.history.length === 0 ? (
        <Card>
          <CardContent className="pt-6 text-center text-muted-foreground">
            No prompts yet. Start optimizing to build your history!
          </CardContent>
        </Card>
      ) : (
        <>
          {data.history.map((item) => (
            <Card key={item.id} className="hover:border-primary/50 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-base">{item.title || "Untitled"}</CardTitle>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(item.createdAt).toLocaleDateString()} at {new Date(item.createdAt).toLocaleTimeString()}
                    </p>
                  </div>
                  {item.saved && (
                    <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded">Saved</span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-1">Original:</p>
                  <p className="text-sm line-clamp-2">{item.original}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-1">Optimized:</p>
                  <p className="text-sm line-clamp-2">{item.optimized}</p>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleCopy(item.optimized, item.id)}
                    className="gap-1"
                  >
                    <Copy className="w-4 h-4" />
                    {copied === item.id ? "Copied" : "Copy"}
                  </Button>
                  {!item.saved && (
                    <Button variant="ghost" size="sm" onClick={() => handleSave(item.id)} className="gap-1">
                      <Save className="w-4 h-4" />
                      Save
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(item.id)}
                    disabled={deleting === item.id}
                    className="gap-1 text-destructive hover:text-destructive"
                  >
                    {deleting === item.id ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Pagination */}
          <div className="flex items-center justify-between pt-4">
            <p className="text-sm text-muted-foreground">
              Page {data.pagination.page} of {data.pagination.pages}
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setPage(Math.max(1, page - 1))} disabled={page === 1}>
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(Math.min(data.pagination.pages, page + 1))}
                disabled={page === data.pagination.pages}
              >
                Next
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  )
}
