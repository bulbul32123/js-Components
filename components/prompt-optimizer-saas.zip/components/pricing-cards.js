"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Check } from "lucide-react"
import { useAuth } from "@/hooks/useAuth"
import { useState } from "react"
import { loadStripe } from "@stripe/js"

const plans = [
  {
    name: "Free",
    tier: "free",
    price: "$0",
    description: "Perfect for getting started",
    features: ["10 prompts/month", "5 API calls/day", "Basic optimization", "Prompt history"],
    cta: "Current Plan",
    ctaVariant: "outline",
  },
  {
    name: "Pro",
    tier: "pro",
    price: "$29",
    period: "/month",
    description: "For serious prompt engineers",
    features: ["500 prompts/month", "100 API calls/day", "Advanced optimization", "Full analytics", "Priority support"],
    cta: "Upgrade to Pro",
    priceId: process.env.NEXT_PUBLIC_STRIPE_PRO_MONTHLY_PRICE_ID,
  },
  {
    name: "Enterprise",
    tier: "enterprise",
    price: "Custom",
    description: "For teams and organizations",
    features: ["Unlimited prompts", "Unlimited API calls", "Custom models", "Dedicated support", "API access"],
    cta: "Contact Sales",
    ctaVariant: "outline",
  },
]

export function PricingCards() {
  const { user } = useAuth()
  const [isLoading, setIsLoading] = useState(null)

  const handleUpgrade = async (priceId) => {
    if (!priceId) return

    setIsLoading(priceId)

    try {
      const token = localStorage.getItem("authToken")
      const res = await fetch("/api/billing/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ priceId }),
      })

      const { sessionId } = await res.json()

      const stripe = await loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY)
      await stripe.redirectToCheckout({ sessionId })
    } catch (err) {
      console.error("Upgrade error:", err)
    } finally {
      setIsLoading(null)
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {plans.map((plan) => (
        <Card key={plan.tier} className={plan.tier === "pro" ? "border-primary shadow-lg" : ""}>
          <CardHeader>
            <CardTitle>{plan.name}</CardTitle>
            <CardDescription>{plan.description}</CardDescription>
            <div className="mt-4">
              <span className="text-3xl font-bold">{plan.price}</span>
              {plan.period && <span className="text-muted-foreground">{plan.period}</span>}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <ul className="space-y-2">
              {plan.features.map((feature, idx) => (
                <li key={idx} className="flex items-center gap-2 text-sm">
                  <Check className="w-4 h-4 text-primary" />
                  {feature}
                </li>
              ))}
            </ul>

            <Button
              onClick={() => handleUpgrade(plan.priceId)}
              disabled={isLoading === plan.priceId || user?.tier === plan.tier}
              variant={plan.ctaVariant || "default"}
              className="w-full"
            >
              {isLoading === plan.priceId ? "Loading..." : plan.cta}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
