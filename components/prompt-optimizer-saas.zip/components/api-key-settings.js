"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Copy, Trash2, Loader2 } from "lucide-react"
import useSWR from "swr"

const fetcher = async (url) => {
  const token = localStorage.getItem("authToken")
  const res = await fetch(url, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  })
  if (!res.ok) throw new Error("Failed to fetch")
  return res.json()
}

export function ApiKeySettings() {
  const { data, mutate } = useSWR("/api/users/profile", fetcher)
  const [isGenerating, setIsGenerating] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [copied, setCopied] = useState(false)
  const [showKey, setShowKey] = useState(false)
  const [apiKey, setApiKey] = useState("")

  const handleGenerateKey = async () => {
    setIsGenerating(true)
    try {
      const token = localStorage.getItem("authToken")
      const res = await fetch("/api/users/api-key", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const result = await res.json()
      if (result.apiKey) {
        setApiKey(result.apiKey)
        setShowKey(true)
        mutate()
      }
    } catch (err) {
      console.error("Error generating API key:", err)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDeleteKey = async () => {
    setIsDeleting(true)
    try {
      const token = localStorage.getItem("authToken")
      const res = await fetch("/api/users/api-key", {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (res.ok) {
        setApiKey("")
        setShowKey(false)
        mutate()
      }
    } catch (err) {
      console.error("Error deleting API key:", err)
    } finally {
      setIsDeleting(false)
    }
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(apiKey)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>API Key</CardTitle>
        <CardDescription>Manage your API key for programmatic access</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {data?.user?.apiKey ? (
          <>
            <div className="bg-muted p-3 rounded-lg">
              <p className="text-xs text-muted-foreground mb-1">Current API Key</p>
              <p className="font-mono text-sm">{data.user.apiKey}</p>
            </div>
            <Button onClick={handleDeleteKey} disabled={isDeleting} variant="destructive" className="w-full gap-2">
              {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
              Delete API Key
            </Button>
          </>
        ) : (
          <>
            <p className="text-sm text-muted-foreground">
              Generate an API key to access the Prompt Optimizer programmatically.
            </p>
            <Button onClick={handleGenerateKey} disabled={isGenerating} className="w-full">
              {isGenerating ? "Generating..." : "Generate API Key"}
            </Button>
          </>
        )}

        {showKey && apiKey && (
          <div className="bg-yellow-500/10 border border-yellow-500/20 p-3 rounded-lg">
            <p className="text-xs font-semibold text-yellow-700 dark:text-yellow-400 mb-2">
              Save your API key securely. You won't be able to see it again.
            </p>
            <div className="bg-background p-2 rounded font-mono text-xs break-all mb-2">{apiKey}</div>
            <Button size="sm" onClick={handleCopy} className="gap-2">
              <Copy className="w-4 h-4" />
              {copied ? "Copied!" : "Copy Key"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
