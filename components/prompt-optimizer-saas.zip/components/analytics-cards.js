"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, BookmarkIcon, Zap, Calendar } from "lucide-react"
import useSWR from "swr"

const fetcher = async (url) => {
  const token = localStorage.getItem("authToken")
  const res = await fetch(url, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  })
  if (!res.ok) throw new Error("Failed to fetch")
  return res.json()
}

export function AnalyticsCards() {
  const { data, error } = useSWR("/api/analytics/stats", fetcher)

  if (error) {
    return <div className="text-destructive">Failed to load analytics</div>
  }

  if (!data) {
    return <div className="text-muted-foreground">Loading analytics...</div>
  }

  const stats = [
    {
      title: "Total Optimized",
      value: data.stats.totalPrompts,
      icon: TrendingUp,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
    },
    {
      title: "Saved Prompts",
      value: data.stats.savedPrompts,
      icon: BookmarkIcon,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
    },
    {
      title: "This Month",
      value: data.stats.thisMonthPrompts,
      icon: Calendar,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
    },
    {
      title: "API Calls Today",
      value: data.stats.apiCallsToday,
      icon: Zap,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, idx) => {
        const Icon = stat.icon
        return (
          <Card key={idx}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
                {stat.title}
                <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                  <Icon className={`w-4 h-4 ${stat.color}`} />
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
