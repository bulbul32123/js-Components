"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Copy } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export function ApiDocumentation() {
  const [copied, setCopied] = useState(null)

  const examples = [
    {
      title: "cURL",
      code: `curl -X POST https://prompt-optimizer.com/api/v1/optimize \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: your-api-key" \\
  -d '{
    "prompt": "Write a function that...",
    "model": "gpt-4"
  }'`,
    },
    {
      title: "JavaScript",
      code: `const response = await fetch('https://prompt-optimizer.com/api/v1/optimize', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'x-api-key': 'your-api-key',
  },
  body: JSON.stringify({
    prompt: 'Write a function that...',
    model: 'gpt-4',
  }),
});

const data = await response.json();
console.log(data.optimized);`,
    },
    {
      title: "Python",
      code: `import requests

response = requests.post(
  'https://prompt-optimizer.com/api/v1/optimize',
  headers={
    'x-api-key': 'your-api-key',
  },
  json={
    'prompt': 'Write a function that...',
    'model': 'gpt-4',
  }
)

data = response.json()
print(data['optimized'])`,
    },
  ]

  const handleCopy = (code, idx) => {
    navigator.clipboard.writeText(code)
    setCopied(idx)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>API Documentation</CardTitle>
          <CardDescription>Use the Prompt Optimizer API in your applications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-semibold text-sm mb-2">Endpoint</h4>
            <code className="bg-muted p-2 rounded text-sm block">POST /api/v1/optimize</code>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-2">Authentication</h4>
            <p className="text-sm text-muted-foreground">
              Include your API key in the <code className="bg-muted px-1 rounded">x-api-key</code> header.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-2">Request Body</h4>
            <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
              {`{
  "prompt": "Your prompt here",
  "model": "gpt-4"  // optional
}`}
            </pre>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-2">Response</h4>
            <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">
              {`{
  "original": "Your prompt here",
  "optimized": "Enhanced prompt...",
  "improvements": ["..."],
  "model": "gpt-4",
  "remaining": 95
}`}
            </pre>
          </div>
        </CardContent>
      </Card>

      {/* Code Examples */}
      {examples.map((example, idx) => (
        <Card key={idx}>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">{example.title}</CardTitle>
              <Button variant="ghost" size="sm" onClick={() => handleCopy(example.code, idx)} className="gap-2">
                <Copy className="w-4 h-4" />
                {copied === idx ? "Copied" : "Copy"}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-3 rounded text-xs overflow-x-auto">{example.code}</pre>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
