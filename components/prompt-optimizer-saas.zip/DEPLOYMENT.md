# Deployment Guide

## Vercel Deployment

### Prerequisites
- GitHub account with repository
- Vercel account
- All environment variables ready

### Steps

1. **Push to GitHub**
\`\`\`bash
git add .
git commit -m "Initial commit"
git push origin main
\`\`\`

2. **Connect to Vercel**
   - Go to https://vercel.com/new
   - Select your GitHub repository
   - Click "Import"

3. **Configure Environment Variables**
   - In Vercel dashboard, go to Settings → Environment Variables
   - Add all variables from `.env.local`:
     - MONGODB_URI
     - MONGODB_DB
     - JWT_SECRET
     - STRIPE_SECRET_KEY
     - STRIPE_PUBLISHABLE_KEY
     - NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
     - STRIPE_WEBHOOK_SECRET
     - STRIPE_PRO_MONTHLY_PRICE_ID
     - STRIPE_PRO_ANNUAL_PRICE_ID
     - STRIPE_ENTERPRISE_PRICE_ID
     - NEXT_PUBLIC_APP_URL (set to your production domain)

4. **Deploy**
   - Click "Deploy"
   - Wait for build to complete (5-10 minutes)
   - Your app is now live!

### Post-Deployment

1. **Update Stripe Webhook**
   - Go to Stripe Dashboard → Developers → Webhooks
   - Update webhook URL to: `https://yourdomain.com/api/webhooks/stripe`

2. **Test Production**
   - Visit your production URL
   - Create a test account
   - Test the full flow

3. **Monitor**
   - Check Vercel Analytics
   - Monitor MongoDB usage
   - Check Stripe dashboard for transactions

## Custom Domain

1. In Vercel dashboard, go to Settings → Domains
2. Add your custom domain
3. Follow DNS configuration instructions
4. Update NEXT_PUBLIC_APP_URL to your domain

## SSL/TLS

Vercel automatically provides SSL certificates for all deployments.

## Performance Optimization

1. **Enable Caching**
   - Vercel caches static assets automatically
   - Configure cache headers in `next.config.mjs`

2. **Database Optimization**
   - Add indexes to MongoDB collections
   - Monitor query performance

3. **API Optimization**
   - Use response caching where appropriate
   - Implement pagination for large datasets

## Monitoring and Logging

1. **Vercel Analytics**
   - Monitor page performance
   - Track user interactions
   - View error rates

2. **MongoDB Monitoring**
   - Check connection pool usage
   - Monitor query performance
   - Set up alerts for high usage

3. **Stripe Monitoring**
   - Monitor transaction success rates
   - Check webhook delivery
   - Review failed payments

## Scaling

As your app grows:

1. **Database**
   - Upgrade MongoDB cluster tier
   - Add read replicas for high traffic
   - Implement caching layer (Redis)

2. **API**
   - Implement rate limiting
   - Add request queuing
   - Use CDN for static assets

3. **Infrastructure**
   - Use Vercel Pro for better performance
   - Add edge functions for low-latency responses
   - Implement background jobs for heavy processing

## Disaster Recovery

1. **Backups**
   - Enable MongoDB automated backups
   - Test restore procedures regularly

2. **Monitoring**
   - Set up alerts for errors
   - Monitor uptime
   - Track performance metrics

3. **Incident Response**
   - Document runbooks for common issues
   - Have rollback procedures ready
   - Maintain communication channels
