"use client"

import type React from "react"

import { useState, useCallback, useMemo } from "react"
import { createEditor, type Descendant, Editor, Transforms, Range, type NodeEntry, Text } from "slate"
import { Slate, Editable, withReact, type RenderLeafProps } from "slate-react"
import { withHistory } from "slate-history"
import { Button } from "@/components/ui/button"
import { Bold, Italic, Underline, Code, Quote, List, ListOrdered } from "lucide-react"
import { ModeToggle } from "@/components/mode-toggle"

// Define custom types for Slate
type CustomElement = {
  type: "paragraph"
  children: CustomText[]
}

type CustomText = {
  text: string
}

declare module "slate" {
  interface CustomTypes {
    Editor: Editor
    Element: CustomElement
    Text: CustomText
  }
}

const initialValue: Descendant[] = [
  {
    type: "paragraph",
    children: [{ text: "Start writing your **markdown** content here with _italic_ and `code` formatting!" }],
  },
]

const insertMarkdownToken = (editor: Editor, token: string, wrapSelection = true) => {
  const { selection } = editor

  if (selection && Range.isCollapsed(selection)) {
    // No selection - insert token pair and position cursor between them
    Editor.insertText(editor, `${token}${token}`)
    Transforms.move(editor, { distance: token.length, reverse: true })
  } else if (selection) {
    // Text is selected - wrap it with tokens
    const selectedText = Editor.string(editor, selection)
    Editor.insertText(editor, `${token}${selectedText}${token}`)
  } else {
    // No selection and no cursor - just insert tokens
    Editor.insertText(editor, `${token}${token}`)
  }
}

const insertBlockToken = (editor: Editor, token: string) => {
  const { selection } = editor
  if (!selection) return

  // Move to start of line
  Transforms.move(editor, { unit: "line", reverse: true })
  Editor.insertText(editor, `${token} `)
}

const insertListToken = (editor: Editor, token: string) => {
  const { selection } = editor
  if (!selection) return

  // Move to start of line
  Transforms.move(editor, { unit: "line", reverse: true })
  Editor.insertText(editor, `${token} `)
}

export default function MarkdownEditor() {
  const [title, setTitle] = useState("Untitled Document")
  const editor = useMemo(() => withHistory(withReact(createEditor())), [])
  const [value, setValue] = useState<Descendant[]>(initialValue)
  const [isEditorFocused, setIsEditorFocused] = useState(false)

  const ensureEditorContent = useCallback(() => {
    if (editor.children.length === 0 || (editor.children.length === 1 && Editor.string(editor, []) === "")) {
      Transforms.insertNodes(editor, {
        type: "paragraph",
        children: [{ text: "" }],
      })
    }
  }, [editor])

  const handleEditorFocus = useCallback(() => {
    try {
      ensureEditorContent()
      setIsEditorFocused(true)
    } catch (error) {
      console.warn("Focus error handled:", error)
      setIsEditorFocused(true)
    }
  }, [ensureEditorContent])

  const handleEditorChange = useCallback((newValue: Descendant[]) => {
    setValue(newValue)

    // Ensure we always have at least one paragraph
    if (newValue.length === 0) {
      const emptyParagraph: Descendant = {
        type: "paragraph",
        children: [{ text: "" }],
      }
      setValue([emptyParagraph])
    }
  }, [])

  const decorate = useCallback(([node, path]: NodeEntry) => {
    const ranges: Range[] = []

    if (!Text.isText(node)) {
      return ranges
    }

    const text = node.text

    // Bold: **text**
    const boldRegex = /\*\*(.*?)\*\*/g
    let match
    while ((match = boldRegex.exec(text)) !== null) {
      ranges.push({
        anchor: { path, offset: match.index },
        focus: { path, offset: match.index + match[0].length },
        bold: true,
      } as Range & { bold: boolean })
    }

    // Italic: *text* or _text_
    const italicRegex = /(?<!\*)\*([^*]+?)\*(?!\*)|_([^_]+?)_/g
    while ((match = italicRegex.exec(text)) !== null) {
      ranges.push({
        anchor: { path, offset: match.index },
        focus: { path, offset: match.index + match[0].length },
        italic: true,
      } as Range & { italic: boolean })
    }

    // Strikethrough: ~~text~~
    const strikeRegex = /~~(.*?)~~/g
    while ((match = strikeRegex.exec(text)) !== null) {
      ranges.push({
        anchor: { path, offset: match.index },
        focus: { path, offset: match.index + match[0].length },
        strikethrough: true,
      } as Range & { strikethrough: boolean })
    }

    // Code: `text`
    const codeRegex = /`([^`]+?)`/g
    while ((match = codeRegex.exec(text)) !== null) {
      ranges.push({
        anchor: { path, offset: match.index },
        focus: { path, offset: match.index + match[0].length },
        code: true,
      } as Range & { code: boolean })
    }

    // Headers: ## text
    const headerRegex = /^(#{1,6})\s+(.*)$/gm
    while ((match = headerRegex.exec(text)) !== null) {
      ranges.push({
        anchor: { path, offset: match.index },
        focus: { path, offset: match.index + match[0].length },
        header: true,
        headerLevel: match[1].length,
      } as Range & { header: boolean; headerLevel: number })
    }

    // Blockquote: > text
    const quoteRegex = /^>\s+(.*)$/gm
    while ((match = quoteRegex.exec(text)) !== null) {
      ranges.push({
        anchor: { path, offset: match.index },
        focus: { path, offset: match.index + match[0].length },
        blockquote: true,
      } as Range & { blockquote: boolean })
    }

    return ranges
  }, [])

  const renderLeaf = useCallback(({ attributes, children, leaf }: RenderLeafProps) => {
    const style: React.CSSProperties = {}
    let className = ""

    if ((leaf as any).bold) {
      style.fontWeight = "bold"
    }

    if ((leaf as any).italic) {
      style.fontStyle = "italic"
    }

    if ((leaf as any).strikethrough) {
      style.textDecoration = "line-through"
    }

    if ((leaf as any).code) {
      className += " bg-muted px-1 py-0.5 rounded text-sm font-mono"
    }

    if ((leaf as any).header) {
      const level = (leaf as any).headerLevel || 1
      style.fontSize = `${2.5 - level * 0.25}rem`
      style.fontWeight = "bold"
      style.display = "block"
      style.marginTop = "1rem"
      style.marginBottom = "0.5rem"
    }

    if ((leaf as any).blockquote) {
      // Simplified to use design system border with reduced thickness
      className += " border-l-2 border-border pl-4 italic text-muted-foreground"
      style.display = "block"
    }

    return (
      <span {...attributes} style={style} className={className}>
        {children}
      </span>
    )
  }, [])

  const renderElement = useCallback((props: any) => {
    return (
      <p {...props.attributes} className="mb-2">
        {props.children}
      </p>
    )
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto p-6">
        {/* Added header with theme toggle */}
        <div className="flex justify-end mb-6">
          <ModeToggle />
        </div>

        {/* Editable Title */}
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="text-4xl font-bold mb-8 bg-transparent border-none outline-none w-full text-foreground placeholder:text-muted-foreground"
          placeholder="Document Title"
        />

        <div
          className={`flex flex-wrap gap-2 p-4 mb-4 rounded-lg transition-opacity duration-200 px-0 py-0 ${
            isEditorFocused ? "opacity-100" : "opacity-0"
          }`}
        >
          <Button
            variant="outline"
            size="sm"
            onMouseDown={(event) => {
              event.preventDefault()
              insertMarkdownToken(editor, "**")
            }}
          >
            <Bold className="h-4 w-4" />
          </Button>

          <Button
            variant="outline"
            size="sm"
            onMouseDown={(event) => {
              event.preventDefault()
              insertMarkdownToken(editor, "*")
            }}
          >
            <Italic className="h-4 w-4" />
          </Button>

          <Button
            variant="outline"
            size="sm"
            onMouseDown={(event) => {
              event.preventDefault()
              insertMarkdownToken(editor, "~~")
            }}
          >
            <Underline className="h-4 w-4" />
          </Button>

          <Button
            variant="outline"
            size="sm"
            onMouseDown={(event) => {
              event.preventDefault()
              insertMarkdownToken(editor, "`")
            }}
          >
            <Code className="h-4 w-4" />
          </Button>

          {/* Reverted to use design system border */}
          <div className="w-px h-6 bg-border mx-1" />

          <Button
            variant="outline"
            size="sm"
            onMouseDown={(event) => {
              event.preventDefault()
              insertBlockToken(editor, "##")
            }}
          >
            H2
          </Button>

          <Button
            variant="outline"
            size="sm"
            onMouseDown={(event) => {
              event.preventDefault()
              insertBlockToken(editor, ">")
            }}
          >
            <Quote className="h-4 w-4" />
          </Button>

          <Button
            variant="outline"
            size="sm"
            onMouseDown={(event) => {
              event.preventDefault()
              insertListToken(editor, "-")
            }}
          >
            <List className="h-4 w-4" />
          </Button>

          <Button
            variant="outline"
            size="sm"
            onMouseDown={(event) => {
              event.preventDefault()
              insertListToken(editor, "1.")
            }}
          >
            <ListOrdered className="h-4 w-4" />
          </Button>
        </div>

        <div className="bg-background">
          <Slate editor={editor} initialValue={value} onValueChange={handleEditorChange}>
            <Editable
              decorate={decorate}
              renderLeaf={renderLeaf}
              renderElement={renderElement}
              placeholder="Start writing..."
              className="min-h-[500px] py-6 focus:outline-none font-mono leading-relaxed"
              spellCheck
              autoFocus
              onFocus={handleEditorFocus}
              onBlur={() => setIsEditorFocused(false)}
            />
          </Slate>
        </div>
      </div>
    </div>
  )
}
