"use client"

import { useId, useState } from "react"
import { CheckIcon, ChevronDownIcon } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

const frameworks = [
  {
    value: "next.js",
    label: "Next.js",
  },
  {
    value: "sveltekit",
    label: "SvelteKit",
  },
  {
    value: "nuxt.js",
    label: "Nuxt.js",
  },
  {
    value: "remix",
    label: "Remix",
  },
  {
    value: "astro",
    label: "Astro",
  },
  {
    value: "angular",
    label: "Angular",
  },
  {
    value: "vue",
    label: "Vue.js",
  },
  {
    value: "react",
    label: "React",
  },
  {
    value: "ember",
    label: "Ember.js",
  },
  {
    value: "gatsby",
    label: "Gatsby",
  },
  {
    value: "eleventy",
    label: "Eleventy",
  },
  {
    value: "solid",
    label: "SolidJS",
  },
  {
    value: "preact",
    label: "Preact",
  },
  {
    value: "qwik",
    label: "Qwik",
  },
  {
    value: "alpine",
    label: "Alpine.js",
  },
  {
    value: "lit",
    label: "Lit",
  },
]

interface SelectWithSearchProps {
  value?: string
  onChange?: (value: string) => void
}

export function SelectWithSearch({ value: externalValue, onChange }: SelectWithSearchProps) {
  const id = useId()
  const [open, setOpen] = useState<boolean>(false)
  const [internalValue, setInternalValue] = useState<string>(externalValue || "")

  // Use external value if provided
  const value = externalValue !== undefined ? externalValue : internalValue

  const handleSelect = (currentValue: string) => {
    const newValue = currentValue === value ? "" : currentValue
    setInternalValue(newValue)
    onChange?.(newValue)
    setOpen(false)
  }

  return (
    <div className="*:not-first:mt-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            id={id}
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="bg-white hover:bg-white border-neutral-200 w-full justify-between px-3 font-normal outline-offset-0 outline-none focus-visible:outline-[3px] dark:bg-neutral-950 dark:hover:bg-neutral-950 dark:border-neutral-800"
          >
            <span className={cn("truncate", !value && "text-neutral-500 dark:text-neutral-400")}>
              {value ? frameworks.find((framework) => framework.value === value)?.label : "Select framework"}
            </span>
            <ChevronDownIcon
              size={16}
              className="text-neutral-500/80 shrink-0 dark:text-neutral-400/80"
              aria-hidden="true"
            />
          </Button>
        </PopoverTrigger>
        <PopoverContent
          className="border-neutral-200 w-full min-w-[var(--radix-popper-anchor-width)] p-0 dark:border-neutral-800"
          align="start"
        >
          <Command>
            <CommandInput className="focus-visible:outline-none" placeholder="Search framework..." />
            <CommandList>
              <CommandEmpty>No framework found.</CommandEmpty>
              <CommandGroup>
                {frameworks.map((framework) => (
                  <CommandItem key={framework.value} value={framework.value} onSelect={handleSelect}>
                    {framework.label}
                    {value === framework.value && <CheckIcon size={16} className="ml-auto" />}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  )
}
