import { PricingCards } from "@/components/pricing-cards"

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 p-4 sm:p-8 flex items-center justify-center font-sans">
      <PricingCards />
    </div>
  )
}
