import { CommandSearch } from "@/components/command-search"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-24">
      <div className="w-full max-w-md">
        <h1 className="mb-6 text-center text-2xl font-bold">Advanced Command Search</h1>
        <p className="mb-8 text-center text-muted-foreground">
          Press <kbd className="rounded border bg-muted px-1 text-xs">⌘K</kbd> to open the command menu
        </p>
        <CommandSearch />
      </div>
    </div>
  )
}
