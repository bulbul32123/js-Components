import NavBar from "@/components/nav-bar"
import Hero from "@/components/hero"
import ImageGrid from "@/components/image-grid"
import TrustedBy from "@/components/trusted-by"
import Footer from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-[#0f0f10] to-[#1a1a1b]">
      <NavBar />
      <Hero />
      <ImageGrid />
      <TrustedBy />
      <Footer />
    </main>
  )
}
