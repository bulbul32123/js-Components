"use client"

import { Globe } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function NavBar() {
  return (
    <nav className="border-b border-white/10 bg-black/40 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <div className="text-2xl font-bold text-white tracking-tight">imgix</div>

        {/* Center Links */}
        <div className="hidden md:flex items-center gap-8">
          {["Customers", "Solutions", "Product", "Pricing", "Partners", "Company"].map((link) => (
            <a key={link} href="#" className="text-sm text-gray-300 hover:text-white transition-colors">
              {link}
            </a>
          ))}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            className="hidden sm:inline-flex border-white/20 text-white hover:bg-white/10 bg-transparent"
          >
            Contact Us
          </Button>
          <Button variant="ghost" className="text-white hover:bg-white/10">
            Log In / Sign Up
          </Button>
          <button className="p-2 hover:bg-white/10 rounded-lg transition-colors">
            <Globe className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </div>
    </nav>
  )
}
