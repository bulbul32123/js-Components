export default function TrustedBy() {
  const logos = [
    { name: "Company 1", initials: "C1" },
    { name: "Company 2", initials: "C2" },
    { name: "Company 3", initials: "C3" },
    { name: "Company 4", initials: "C4" },
    { name: "Company 5", initials: "C5" },
  ]

  return (
    <section className="py-16 px-6 border-t border-white/10">
      <div className="max-w-6xl mx-auto">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-widest text-center mb-8">Trusted By</p>
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
          {logos.map((logo) => (
            <div
              key={logo.name}
              className="w-24 h-12 bg-white/5 border border-white/10 rounded-lg flex items-center justify-center hover:bg-white/10 transition-colors"
            >
              <span className="text-sm font-semibold text-gray-400">{logo.initials}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
