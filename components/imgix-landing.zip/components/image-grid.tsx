"use client"

import { motion } from "framer-motion"
import Image from "next/image"

interface GridCard {
  id: string
  label: string
  image: string
  alt: string
  badge?: string
  size?: "small" | "large"
}

const cards: GridCard[] = [
  {
    id: "auto-tagging",
    label: "AUTO-TAGGING",
    image: "/green-wall-with-cactus-plant.jpg",
    alt: "Cactus plant on green wall",
    size: "small",
  },
  {
    id: "generative-fill",
    label: "GENERATIVE FILL",
    image: "/flamingo-bird-in-water.jpg",
    alt: "Flamingo in tropical water",
    size: "large",
  },
  {
    id: "background-removal",
    label: "BACKGROUND REMOVAL",
    image: "/orange-fruit-with-leaves.jpg",
    alt: "Orange fruit with green leaves",
    size: "small",
  },
  {
    id: "focal-point-crop",
    label: "FOCAL-POINT CROP",
    image: "/portrait-of-woman-with-freckles.jpg",
    alt: "Portrait of woman with freckles",
    size: "small",
  },
  {
    id: "auto-compress",
    label: "AUTO-COMPRESS",
    image: "/pink-donuts-with-yellow-lemon.jpg",
    alt: "Pink donuts with lemon",
    badge: "187 kb",
    size: "small",
  },
]

export default function ImageGrid() {
  return (
    <section className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-max">
          {cards.map((card, index) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`relative group overflow-hidden rounded-2xl shadow-lg ${
                card.size === "large" ? "md:col-span-1 md:row-span-2" : ""
              }`}
            >
              {/* Image Container */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.3 }}
                className="relative w-full h-64 md:h-80 overflow-hidden"
              >
                <Image
                  src={card.image || "/placeholder.svg"}
                  alt={card.alt}
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                />
              </motion.div>

              {/* Label Badge */}
              <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-sm px-3 py-1 rounded-full">
                <span className="text-xs font-semibold text-white tracking-wider">{card.label}</span>
              </div>

              {/* File Size Badge (for auto-compress) */}
              {card.badge && (
                <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                  <span className="text-xs font-semibold text-black">{card.badge}</span>
                </div>
              )}

              {/* Hover Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                whileHover={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
                className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
