"use client"

import { Button } from "@/components/ui/button"

export default function Hero() {
  return (
    <section className="relative py-20 px-6 text-center">
      <div className="max-w-4xl mx-auto">
        {/* Subtitle */}
        <p className="text-xs font-semibold text-gray-400 uppercase tracking-widest mb-6">Your Images Matter</p>

        {/* Main Heading */}
        <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight text-balance">
          Combine images, data, and intelligence to transform your business
        </h1>

        {/* Description */}
        <p className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto leading-relaxed text-pretty">
          We empower marketers, developers, and designers to optimize, transform, and deliver images instantly across
          all digital platforms and devices.
        </p>

        {/* CTA Button */}
        <Button size="lg" className="bg-white text-black hover:bg-gray-100 font-semibold px-8 py-6 text-base">
          Start For Free
        </Button>
      </div>
    </section>
  )
}
