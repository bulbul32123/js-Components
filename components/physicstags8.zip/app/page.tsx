"use client"
import TagCanvas from "@/components/tag-canvas"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-4">
      <TagCanvas />
      <a
        href="https://tulioportela.com"
        target="_blank"
        rel="noopener noreferrer"
        className="text-sm text-gray-400 mt-4 hover:text-gray-600 transition-colors"
      >
        by tulioportela.com
      </a>
    </main>
  )
}
