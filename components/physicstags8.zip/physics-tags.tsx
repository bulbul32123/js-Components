"use client"

import { useEffect, useRef, useState } from "react"

// Matter.js types (simplified for this implementation)
declare global {
  interface Window {
    Matter: any
  }
}

const tags = [
  { text: "Product Design", color: "#e6308a" },
  { text: "Frontend Development", color: "#d54f01" },
  { text: "UI/UX Design", color: "#0461cf" },
  { text: "Design Systems", color: "#22a53c" },
  { text: "Creative Development", color: "#5928ed" },
  { text: "Web Development", color: "#dc143c" },
  { text: "React", color: "#22a53c" },
  { text: "TypeScript", color: "#0461cf" },
]

export default function PhysicsTags() {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const engineRef = useRef<any>(null)
  const tagElementsRef = useRef<HTMLDivElement[]>([])
  const tagBodiesRef = useRef<any[]>([])
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Load Matter.js from CDN
    const script = document.createElement("script")
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/matter-js/0.19.0/matter.min.js"
    script.onload = () => {
      setIsLoaded(true)
    }
    document.head.appendChild(script)

    return () => {
      document.head.removeChild(script)
    }
  }, [])

  useEffect(() => {
    if (!isLoaded || !containerRef.current) return

    const Matter = window.Matter
    const Engine = Matter.Engine
    const Render = Matter.Render
    const World = Matter.World
    const Bodies = Matter.Bodies
    const MouseConstraint = Matter.MouseConstraint
    const Mouse = Matter.Mouse
    const Events = Matter.Events

    const container = containerRef.current
    const containerWidth = container.clientWidth
    const containerHeight = container.clientHeight

    // Create engine
    const engine = Engine.create()
    const world = engine.world
    engineRef.current = engine

    // Set gravity
    engine.world.gravity.y = 0.8

    // Create renderer
    const render = Render.create({
      element: container,
      canvas: canvasRef.current!,
      engine: engine,
      options: {
        width: containerWidth,
        height: containerHeight,
        background: "transparent",
        wireframes: false,
        showVelocity: false,
        showAngleIndicator: false,
        showDebug: false,
      },
    })

    // Create boundaries
    const thickness = 50
    const ground = Bodies.rectangle(
      containerWidth / 2,
      containerHeight + thickness / 2,
      containerWidth + thickness * 2,
      thickness,
      {
        isStatic: true,
        render: { fillStyle: "transparent" },
      },
    )

    const wallLeft = Bodies.rectangle(-thickness / 2, containerHeight / 2, thickness, containerHeight + thickness * 2, {
      isStatic: true,
      render: { fillStyle: "transparent" },
    })

    const wallRight = Bodies.rectangle(
      containerWidth + thickness / 2,
      containerHeight / 2,
      thickness,
      containerHeight + thickness * 2,
      {
        isStatic: true,
        render: { fillStyle: "transparent" },
      },
    )

    World.add(world, [ground, wallLeft, wallRight])

    // Create tag bodies
    const tagBodies = tagElementsRef.current
      .map((tagElement, index) => {
        if (!tagElement) return null

        const rect = tagElement.getBoundingClientRect()
        const containerRect = container.getBoundingClientRect()

        const width = rect.width
        const height = rect.height

        // Random starting position at the top
        const x = Math.random() * (containerWidth - width) + width / 2
        const y = -height - Math.random() * 200

        const body = Bodies.rectangle(x, y, width, height, {
          chamfer: { radius: height / 2 },
          density: 0.001,
          friction: 0.3,
          frictionAir: 0.01,
          restitution: 0.6,
          render: {
            fillStyle: "transparent",
          },
        })

        World.add(world, body)
        return { body, element: tagElement, index }
      })
      .filter(Boolean)

    tagBodiesRef.current = tagBodies

    // Sync positions
    const updatePositions = () => {
      tagBodies.forEach(({ body, element }) => {
        const { x, y } = body.position
        const angle = body.angle

        element.style.transform = `translate(-50%, -50%) translate(${x}px, ${y}px) rotate(${angle}rad)`
        element.style.left = "0px"
        element.style.top = "0px"
      })
    }

    Events.on(engine, "afterUpdate", updatePositions)

    // Add mouse constraint for dragging
    const mouse = Mouse.create(render.canvas)
    const mouseConstraint = MouseConstraint.create(engine, {
      mouse: mouse,
      constraint: {
        stiffness: 0.2,
        render: {
          visible: false,
        },
      },
    })

    World.add(world, mouseConstraint)

    // Start the engine and renderer
    Render.run(render)
    Engine.run(engine)

    // Handle resize
    const handleResize = () => {
      const newWidth = container.clientWidth
      const newHeight = container.clientHeight

      render.canvas.width = newWidth
      render.canvas.height = newHeight
      render.options.width = newWidth
      render.options.height = newHeight
    }

    window.addEventListener("resize", handleResize)

    // Cleanup
    return () => {
      window.removeEventListener("resize", handleResize)
      Render.stop(render)
      Engine.clear(engine)
      World.clear(world, false)
    }
  }, [isLoaded])

  const handleTagClick = (index: number) => {
    console.log(`Clicked on tag: ${tags[index].text}`)
    // Add your click handler logic here
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#f4f9fd] p-4">
      <div
        ref={containerRef}
        className="relative w-full max-w-2xl h-[60vh] border-2 border-[#001d44] rounded-lg bg-white overflow-hidden"
      >
        <h2 className="absolute top-3 left-4 text-lg font-bold text-[#001d44] uppercase tracking-wide z-10">
          My Toolbox
        </h2>

        <canvas ref={canvasRef} className="absolute inset-0 pointer-events-auto" />

        {tags.map((tag, index) => (
          <div
            key={index}
            ref={(el) => {
              if (el) tagElementsRef.current[index] = el
            }}
            className="absolute inline-flex justify-center items-center px-4 h-10 text-sm font-medium text-white uppercase rounded-full shadow-lg cursor-pointer transition-transform hover:scale-105 select-none"
            style={{
              backgroundColor: tag.color,
              pointerEvents: "auto",
              zIndex: 20,
            }}
            onClick={() => handleTagClick(index)}
          >
            {tag.text}
          </div>
        ))}

        {!isLoaded && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-[#001d44] font-medium">Loading physics engine...</div>
          </div>
        )}
      </div>
    </div>
  )
}
