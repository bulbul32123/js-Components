import { FileTree } from "@/components/file-tree"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <div className="max-w-md w-full">
        {/* You can specify any initial path here */}
        <FileTree initialPath="/Documents/Work" />
      </div>
    </main>
  )
}
